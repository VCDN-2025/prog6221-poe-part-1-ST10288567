﻿using System;
using System.Media;
using System.Threading;

namespace CybersecurityChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set the console window title
            Console.Title = "Cybersecurity Awareness Assistant";

            // Play an audio greeting (WAV file)
            PlayVoiceGreeting();

            // Display ASCII art banner
            DisplayAsciiArt();

            // Ask for user's name and greet them
            GreetUser();

            // Begin handling user input in a loop
            HandleUserInput();

            // Exit message
            Console.WriteLine("\nThanks for chatting with me! Stay safe online. 👋");
        }

        // Plays a greeting audio file
        static void PlayVoiceGreeting()
        {
            try
            {
                SoundPlayer player = new SoundPlayer("GreetingAudio.wav");
                player.PlaySync(); // Play audio synchronously
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("⚠️ Voice greeting could not be played: " + ex.Message);
                Console.ResetColor();
            }
        }

        // Displays stylized ASCII art title
        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
  ____  __  __    _    ____ _____ _____     ____   ___ _____ 
 / ___||  \/  |  / \  | __ )_   _| ____|   | __ ) / _ \_   _|
 \___ \| |\/| | / _ \ |  _ \ | | |  _|     |  _ \| | | || |  
  ___) | |  | |/ ___ \| |_) || | | |___    | |_) | |_| || |  
 |____/|_|  |_/_/   \_\____/ |_| |_____|   |____/ \___/ |_|  
                                                            
    ");
            Console.ResetColor();
        }

        // Asks the user for their name and greets them
        static void GreetUser()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n What's your name? ");
            Console.ResetColor();

            string name = Console.ReadLine();

            Console.ForegroundColor = ConsoleColor.Green;
            TypeEffect($"\nWelcome, {name}! I'm your Cybersecurity Awareness Assistant.");
            Console.ResetColor();
        }

        // Continuously handles user input until "exit" is typed
        static void HandleUserInput()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("\n Ask me a cybersecurity question (or type 'exit'): ");
                Console.ResetColor();






                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("⚠️ Please enter something. I can’t help if I don’t understand.");
                    Console.ResetColor();
                    continue;
                }

                if (input.ToLower() == "exit") break;

                RespondToUser(input);
            }
        }














        // Responds to user input with predefined messages
        static void RespondToUser(string input)
        {
            input = input.ToLower(); // Normalize input

            Console.ForegroundColor = ConsoleColor.Cyan;












            // Simple keyword matching to determine response
            if (input.Contains("HI There"))
                TypeEffect("I'm Smart Bot,  I'm functioning as expected and ready to help!");
            else if (input.Contains("purpose"))


                TypeEffect("My purpose is to help you stay safe online by teaching you good cybersecurity practices.");
            else if (input.Contains("password"))


                TypeEffect("Use strong, unique passwords. Avoid reusing passwords and consider using a password manager.");
            else if (input.Contains("phishing"))


                TypeEffect("Phishing attempts often come via fake emails or SMS. Never click suspicious links or share your credentials.");
            else if (input.Contains("browsing"))


                TypeEffect("Use updated browsers, avoid suspicious websites, and enable safe browsing features.");
            else
                TypeEffect("I didn’t quite understand that. Could you rephrase your question?");

            Console.ResetColor();
        }











        // Simulates a typing effect when displaying messages
        static void TypeEffect(string message, int delay = 30)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(delay); // Delay between characters
            }
            Console.WriteLine();
        }
    }
}






//Reference List

//Date: 23 April 2025

//Author: Darsh Somayi

//Sources used to help code : 

//Troelsen, A. & Japikse, P., 2022. Pro C# 10 with .NET 6: Foundational Principles and Practices in Programming. 11th ed. New York: Apress.

//W3Schools, 2025. W3Schools Online Web Tutorials. [online] Available at: https://www.w3schools.com [Accessed 23 Apr. 2025].



